getDate = () =>{
    document.getElementById('date').innerHTML = Date();
}